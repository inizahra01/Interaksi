package com.example.intentprojects

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var btnSubmit : Button
    private lateinit var btnData : Button

    private lateinit var txtValueResult : TextView

    private val resultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == TambahActivity.RESULT_CODE && result.data != null) {
            val selectedValue =
                result.data?.getStringExtra(TambahActivity.EXTRA_SELECTED_VALUE)
            txtValueResult.text = "Jenis Kelamin Yang Anda Pilih Adalah: : $selectedValue"
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val btnSubmit: Button = findViewById(R.id.btn_pindah_halaman)
        btnSubmit.setOnClickListener(this)

        val btnData: Button = findViewById(R.id.btn_pindah_halaman_dengandata)
        btnData.setOnClickListener(this)

        val btnObjek: Button = findViewById(R.id.btn_pindah_denganobjek)
        btnObjek.setOnClickListener(this)

        val btnDial: Button = findViewById(R.id.btn_dial)
        btnDial.setOnClickListener(this)

        val btnOpenAnotherApps: Button = findViewById(R.id.btn_open_anotherapps)
        btnOpenAnotherApps.setOnClickListener(this)

        val btnForResult: Button = findViewById(R.id.btn_for_result)
        btnForResult.setOnClickListener(this)

        txtValueResult = findViewById(R.id.txt_result)
    }

    override fun onClick(v: View) {
        when(v.id) {
            R.id.btn_pindah_halaman -> {
                val PindahIntent = Intent(this@MainActivity, SecondActivity::class.java)
                startActivity(PindahIntent)
            }

            R.id.btn_pindah_halaman_dengandata -> {
                val PindahDataIntent = Intent(this@MainActivity, PindahDenganData::class.java)
                PindahDataIntent.putExtra(PindahDenganData.EXTRA_NAME, "Nurul Fithriani Zahra")
                PindahDataIntent.putExtra(PindahDenganData.EXTRA_AGE, 21)
                startActivity(PindahDataIntent)
            }

            R.id.btn_pindah_denganobjek -> {
                val person = Person(
                    "Nurul Fithriani Zahra",
                    22,
                    "nurulfithrianizahra@gmail.com",
                    "Bandung"
                )

                val PindahObjekIntent = Intent(this@MainActivity, PindahDenganObjek::class.java)
                PindahObjekIntent.putExtra(PindahDenganObjek.EXTRA_PERSON, person)
                startActivity(PindahObjekIntent)
            }

            R.id.btn_dial -> {
                val phoneNumber = "081775465530"
                val dialPhoneIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialPhoneIntent)

            }

            R.id.btn_open_anotherapps -> {
                val openAnotherApps = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/IniZahra01"))
                startActivity(openAnotherApps)
            }

            R.id.btn_for_result -> {
                val forResultIntent = Intent(this@MainActivity, TambahActivity::class.java)
                resultLauncher.launch(forResultIntent)
            }

        }
    }
}


/*
NIM : 10122066
Nama : Nurul Fithriani Zahra
Kelas : IF-2
*/