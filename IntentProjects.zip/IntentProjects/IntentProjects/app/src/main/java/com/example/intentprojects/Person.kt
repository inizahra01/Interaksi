package com.example.intentprojects

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Person(
    val name: String?,
    val age: Int?,
    val email: String?,
    val city: String?
) : Parcelable


/*
NIM : 10122066
Nama : Nurul Fithriani Zahra
Kelas : IF-2
*/